// Shopify Storefront API functions
