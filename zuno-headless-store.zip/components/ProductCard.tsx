// ProductCard component
